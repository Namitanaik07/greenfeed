import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X, Leaf } from 'lucide-react';
import { useScrollToSection } from '@/hooks/useScrollToSection';
import { useNavigate, useLocation } from 'react-router-dom';

const links = [
  { label: 'Spot Issues', id: 'spot-issues' },
  { label: 'Take Action', id: 'take-action' },
  { label: 'Verification', id: 'verification' },
  { label: 'Rewards', id: 'rewards' },
  { label: 'Heatmap', id: 'heatmap', route: '/heatmap' },
  { label: 'Profile', id: 'profile' },
] as const;

const NavBar = () => {
  const [open, setOpen] = useState(false);
  const scrollToSection = useScrollToSection();
  const navigate = useNavigate();
  const location = useLocation();

  const handleNav = (id: string, route?: string) => {
    if (route) {
      navigate(route);
    } else if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => scrollToSection(id), 300);
    } else {
      scrollToSection(id);
    }
    setOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-background/70 border-b border-primary/10">
      <div className="container mx-auto flex items-center justify-between h-16 px-4">
        <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-2">
          <Leaf className="w-7 h-7 text-primary" />
          <span className="font-orbitron font-bold text-lg text-foreground">GreenFeed</span>
        </button>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-6">
          {links.map((l) => (
            <button
              key={l.id}
              onClick={() => handleNav(l.id, 'route' in l ? l.route : undefined)}
              className="text-sm text-foreground/60 hover:text-primary transition-colors font-medium"
            >
              {l.label}
            </button>
          ))}
          <Button size="sm" className="bg-gradient-primary text-primary-foreground font-semibold rounded-lg glow-primary" onClick={() => handleNav('spot-issues')}>
            Get Started
          </Button>
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden text-foreground" onClick={() => setOpen(!open)}>
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-background/95 backdrop-blur-xl border-b border-primary/10 px-4 pb-4 space-y-2">
          {links.map((l) => (
            <button
              key={l.id}
              onClick={() => handleNav(l.id, 'route' in l ? l.route : undefined)}
              className="block w-full text-left py-3 px-4 text-foreground/70 hover:text-primary hover:bg-primary/5 rounded-lg transition-colors text-sm"
            >
              {l.label}
            </button>
          ))}
          <Button className="w-full bg-gradient-primary text-primary-foreground font-semibold rounded-lg glow-primary mt-2" onClick={() => handleNav('spot-issues')}>
            Get Started
          </Button>
        </div>
      )}
    </nav>
  );
};

export default NavBar;
